<?php
    session_start();
    $titre = "About Us";
    include 'header.inc.php';
    include 'menu.inc.php';
?>
<div class="container">
    <h1>About us !</h1>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>

</div>
<?php
    include 'footer.inc.php';
?>