<?php
    session_start();
    $titre = "Une autre page...";
    include 'header.inc.php';
    include 'menu.inc.php';
?>
<div class="container">
    <h1>Autre page</h1>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>
    <p>Bla bla bla...</p>

</div>
<?php
    include 'footer.inc.php';
?>