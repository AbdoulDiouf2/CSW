<?php
  $host="localhost";
  $login="root";
  $passwd="root";
  $dbname="amphi2";
?>