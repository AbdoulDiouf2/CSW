<?php
    session_start();
    $titre = "Administrateur";
    include 'header.inc.php';
    include 'menuadmin.php';
?>
<div class="container">
<h1>Contenu</h1>



<table class="table">
  <thead>
    <tr>
      <th scope="col">#</th>
      <th scope="col">Nom du jeu</th>
      <th scope="col">date du jeu</th>
    </tr>
  </thead>
  <tbody>
  
  <?php
require_once("param.inc.php");
$mysqli = mysqli_connect("localhost","root",$passwd,"tp");
/*
// Connexion :
require_once("param.inc.php");
$mysqli = new mysqli($host, $login, $passwd, $dbname);
if ($mysqli->connect_error) {
    die('Erreur de connexion (' . $mysqli->connect_errno . ') '
            . $mysqli->connect_error);
}
*/
$requeteSelect1 = $mysqli->prepare("SELECT id_Jeu FROM creationjeu");
$requeteSelect1->execute();
$requeteSelect1->bind_result($idJeu);
$requeteSelect1->fetch();
$requeteSelect1->close();
$requeteSelect2 = $mysqli->prepare("SELECT date_Jeu FROM creationjeu");
$requeteSelect2->execute();
$requeteSelect2->bind_result($dateJeu);
$requeteSelect2->fetch();
$requeteSelect2->close();
$requeteCount = $mysqli->prepare("SELECT COUNT(id_CreaJeu FROM creationjeu");
$requeteCount->execute();
$requeteCount->bind_result($nb_ligne);
$requeteCount->fetch();
$requeteCount->close();

$stmt1 = $mysqli->prepare("SELECT nom_jeu FROM jeu WHERE id_Jeu = ?")
$stmt1->bind_param("i", $idJeu);
$stmt1->execute();
$stmt1->bind_result($nomJeu);

  for($i=0; $i<$nb_ligne; $i++)   {
    echo '<tr>';     
    echo  '<th scope="row">'.$i.'</th>';
    echo  '<th scope="row">'.$nomJeu.'</th>';
    echo  '<th scope="row">'.$dateJeu.'</th>';
    echo '</tr>';
  
}

?>

</tbody>

</table>


</div>
<?php
    include 'footer.inc.php';
?>
